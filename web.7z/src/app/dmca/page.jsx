import Header from "../../components/Header";
import Footer from "../../components/Footer";

export default function DMCAPage() {
  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                DMCA <em className="font-medium text-[#4ade80]">Policy</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-8 max-w-[65ch] mx-auto">
                Our policy for handling copyright infringement claims under the Digital Millennium Copyright Act.
              </p>
              
              <p className="text-sm text-[#a3d9a3]">
                Last updated: January 15, 2025
              </p>
            </div>
          </div>
        </section>

        {/* DMCA Content */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[800px] mx-auto">
            <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8 md:p-12">
              <div className="prose prose-invert prose-green max-w-none">
                <div className="text-[#a3d9a3] leading-relaxed space-y-8">
                  
                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">1. Overview</h2>
                    <p>
                      Basic SMP respects the intellectual property rights of others and expects 
                      our users to do the same. We will respond to valid notices of alleged 
                      copyright infringement that comply with the Digital Millennium Copyright 
                      Act ("DMCA").
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">2. Copyright Infringement Claims</h2>
                    <p className="mb-4">
                      If you believe that your copyrighted work has been copied in a way that 
                      constitutes copyright infringement and is accessible through our services, 
                      please notify our designated copyright agent with the following information:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>A physical or electronic signature of the copyright owner or authorized agent</li>
                      <li>Identification of the copyrighted work claimed to have been infringed</li>
                      <li>Identification of the material that is claimed to be infringing with enough detail to locate it</li>
                      <li>Your contact information (address, phone number, email address)</li>
                      <li>A statement that you have a good faith belief that the use is not authorized</li>
                      <li>A statement that the information in the notification is accurate and that you are authorized to act on behalf of the owner</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">3. Designated Copyright Agent</h2>
                    <p className="mb-4">
                      Please send DMCA notices to our designated copyright agent:
                    </p>
                    <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                      <p className="text-white font-semibold">DMCA Agent - Basic SMP</p>
                      <p>Email: dmca@basicsmp.com</p>
                      <p>Subject Line: "DMCA Takedown Request"</p>
                    </div>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">4. Counter-Notification Process</h2>
                    <p className="mb-4">
                      If you believe your content was removed in error, you may file a counter-notification containing:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Your physical or electronic signature</li>
                      <li>Identification of the removed material and its previous location</li>
                      <li>A statement under penalty of perjury that the material was removed in error</li>
                      <li>Your name, address, phone number, and consent to jurisdiction</li>
                      <li>Agreement to accept service of process from the complaining party</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">5. Repeat Infringer Policy</h2>
                    <p>
                      Basic SMP will terminate user accounts that are found to be repeat infringers 
                      in appropriate circumstances. We maintain a policy of terminating access to 
                      our services for users who are found to repeatedly infringe copyrights.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">6. Minecraft-Specific Content</h2>
                    <p className="mb-4">
                      Regarding Minecraft-related content on our server:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>We respect Mojang Studios' intellectual property rights</li>
                      <li>Player-created builds and content remain the property of their creators</li>
                      <li>We do not claim ownership of player creations</li>
                      <li>Custom server content (plugins, configurations) are our intellectual property</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">7. Response Time</h2>
                    <p>
                      We will respond to valid DMCA notices as quickly as possible, typically 
                      within 2-5 business days. If material is found to be infringing, we will 
                      remove or disable access to it promptly.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">8. False Claims</h2>
                    <p>
                      Please note that filing a false DMCA notice may result in liability for 
                      damages, including attorney fees. Ensure that you have a good faith belief 
                      that the use of copyrighted material is not authorized before filing a claim.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">9. Limitation of Liability</h2>
                    <p>
                      Basic SMP acts as a service provider and is not responsible for the content 
                      uploaded or created by users. We will cooperate with valid legal requests 
                      but cannot be held liable for user-generated content.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">10. Alternative Dispute Resolution</h2>
                    <p>
                      Before filing a DMCA notice, we encourage copyright holders to contact us 
                      directly through our support channels to attempt to resolve any disputes 
                      amicably and efficiently.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">11. Updates to This Policy</h2>
                    <p>
                      This DMCA policy may be updated from time to time to reflect changes in 
                      law or our procedures. We will post any updates on this page with a new 
                      "last updated" date.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">12. Contact Information</h2>
                    <p className="mb-4">
                      For general questions about this policy (not DMCA notices):
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Use our website contact form</li>
                      <li>Join our Discord server</li>
                      <li>Email: support@basicsmp.com</li>
                    </ul>
                    <p className="mt-6 text-sm border-t border-[#2d5a2d] pt-6">
                      <strong className="text-white">Important:</strong> For actual DMCA takedown requests, 
                      please use the designated copyright agent contact information provided above.
                    </p>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}