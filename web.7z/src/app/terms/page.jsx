import Header from "../../components/Header";
import Footer from "../../components/Footer";

export default function TermsPage() {
  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                Terms & <em className="font-medium text-[#4ade80]">Conditions</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-8 max-w-[65ch] mx-auto">
                Please read these terms carefully before using Basic SMP services.
              </p>
              
              <p className="text-sm text-[#a3d9a3]">
                Last updated: January 15, 2025
              </p>
            </div>
          </div>
        </section>

        {/* Terms Content */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[800px] mx-auto">
            <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8 md:p-12">
              <div className="prose prose-invert prose-green max-w-none">
                <div className="text-[#a3d9a3] leading-relaxed space-y-8">
                  
                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">1. Acceptance of Terms</h2>
                    <p>
                      By accessing and using Basic SMP services, including our Minecraft server, 
                      website, and Discord community, you agree to be bound by these Terms and 
                      Conditions and our Privacy Policy.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">2. Server Rules and Conduct</h2>
                    <p className="mb-4">
                      When using our Minecraft server, you agree to:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Treat all players and staff with respect</li>
                      <li>Not engage in griefing, stealing, or destruction of other players' builds</li>
                      <li>Not use cheats, hacks, or unauthorized modifications</li>
                      <li>Not spam chat or use inappropriate language</li>
                      <li>Follow all server-specific rules as posted in-game or on Discord</li>
                      <li>Not attempt to exploit server vulnerabilities or bugs</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">3. Account Responsibility</h2>
                    <p className="mb-4">
                      You are responsible for:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Your Minecraft account security and access</li>
                      <li>All activities that occur under your account</li>
                      <li>Maintaining accurate contact information</li>
                      <li>Notifying us immediately of any unauthorized use</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">4. Purchases and Payments</h2>
                    <p className="mb-4">
                      For store purchases:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>All purchases are final and non-refundable unless required by law</li>
                      <li>Digital items are delivered to your server account only</li>
                      <li>We reserve the right to modify store items and prices</li>
                      <li>Chargebacks may result in permanent server ban</li>
                      <li>You must use your own payment methods</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">5. Intellectual Property</h2>
                    <p className="mb-4">
                      Basic SMP and its content are protected by intellectual property laws:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Our server name, logos, and custom content are our property</li>
                      <li>You may not redistribute or resell our custom content</li>
                      <li>Player creations remain the property of their creators</li>
                      <li>We respect Minecraft's terms of service and EULA</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">6. Termination and Bans</h2>
                    <p className="mb-4">
                      We reserve the right to:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Temporarily or permanently ban players for rule violations</li>
                      <li>Terminate service at any time with or without notice</li>
                      <li>Remove or modify player content that violates our terms</li>
                      <li>Refuse service to anyone for any reason</li>
                    </ul>
                    <p className="mt-4">
                      Banned players are not entitled to refunds for purchased items or ranks.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">7. Limitation of Liability</h2>
                    <p>
                      Basic SMP is provided "as is" without warranties. We are not liable for 
                      any damages arising from your use of our services, including but not limited 
                      to loss of in-game items, progress, or data.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">8. Server Availability</h2>
                    <p className="mb-4">
                      While we strive for 24/7 uptime:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>We do not guarantee uninterrupted service</li>
                      <li>Maintenance windows may be scheduled with advance notice</li>
                      <li>Emergency maintenance may occur without notice</li>
                      <li>We are not liable for downtime or service interruptions</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">9. Age Requirements</h2>
                    <p>
                      You must be at least 13 years old to use our services. Players under 18 
                      should have parental permission before making any purchases.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">10. Changes to Terms</h2>
                    <p>
                      We may modify these terms at any time. Significant changes will be announced 
                      on our Discord server and website. Continued use of our services after changes 
                      constitutes acceptance of the new terms.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">11. Dispute Resolution</h2>
                    <p className="mb-4">
                      For any disputes:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>First, contact us through our support channels</li>
                      <li>We will work to resolve issues fairly and promptly</li>
                      <li>Serious disputes may be handled through mediation</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">12. Contact Information</h2>
                    <p className="mb-4">
                      For questions about these terms:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Use our website contact form</li>
                      <li>Join our Discord server</li>
                      <li>Email: support@basicsmp.com</li>
                    </ul>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}