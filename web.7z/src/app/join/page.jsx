import { useState } from "react";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { Copy, CheckCircle, Monitor, Smartphone, HelpCircle, ExternalLink } from "lucide-react";

export default function JoinPage() {
  const [activeTab, setActiveTab] = useState("java");
  const [copied, setCopied] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState(null);

  const serverIPs = {
    java: "play.basicsmp.com",
    bedrock: "play.basicsmp.com:19132"
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const javaSteps = [
    {
      step: 1,
      title: "Open Minecraft Java Edition",
      description: "Launch Minecraft Java Edition on your PC or Mac. Make sure you're running version 1.20 or higher."
    },
    {
      step: 2,
      title: "Go to Multiplayer",
      description: "Click on 'Multiplayer' from the main menu."
    },
    {
      step: 3,
      title: "Add Server",
      description: "Click 'Add Server' to create a new server entry."
    },
    {
      step: 4,
      title: "Enter Server Details",
      description: "Server Name: Basic SMP\nServer Address: play.basicsmp.com"
    },
    {
      step: 5,
      title: "Join and Play!",
      description: "Click 'Done' then double-click on Basic SMP to join our server!"
    }
  ];

  const bedrockSteps = [
    {
      step: 1,
      title: "Open Minecraft Bedrock",
      description: "Launch Minecraft Bedrock Edition on your device (Mobile, Console, or Windows 10)."
    },
    {
      step: 2,
      title: "Go to Play",
      description: "Click on 'Play' from the main menu."
    },
    {
      step: 3,
      title: "Select Servers",
      description: "Navigate to the 'Servers' tab at the top."
    },
    {
      step: 4,
      title: "Add External Server",
      description: "Scroll down and click 'Add Server' or look for the '+' button."
    },
    {
      step: 5,
      title: "Enter Server Details",
      description: "Server Name: Basic SMP\nServer Address: play.basicsmp.com\nPort: 19132"
    },
    {
      step: 6,
      title: "Join and Play!",
      description: "Tap on the Basic SMP server to join our cross-play community!"
    }
  ];

  const faqItems = [
    {
      question: "What Minecraft versions are supported?",
      answer: "We support Minecraft Java Edition 1.20+ and Bedrock Edition (latest version). Both can play together on our server!"
    },
    {
      question: "I can't connect to the server, what should I do?",
      answer: "First, check that you're using the correct IP address. Make sure your Minecraft version is supported. If you're still having issues, try restarting your game or checking your internet connection. You can also ask for help in our Discord server."
    },
    {
      question: "Is the server always online?",
      answer: "Yes! Basic SMP runs 24/7 with 99.9% uptime. We perform maintenance during low-traffic hours and always announce it in advance on Discord."
    },
    {
      question: "Do I need to install any mods?",
      answer: "No mods are required! Basic SMP is a vanilla-enhanced server that works with the standard Minecraft client. However, some optional client-side mods like Optifine are allowed."
    },
    {
      question: "Are there any rules I should know about?",
      answer: "Yes, we have a simple set of rules focused on respect, fair play, and fun. The full rules are available in-game and on our Discord. Key points: no griefing, no cheating, be respectful to other players."
    },
    {
      question: "How do I claim land to protect my builds?",
      answer: "We use a simple land claiming system. Once you join, you'll get a claiming tool. Use it to select an area and protect your builds from griefing. New players get enough claim blocks to protect a starter base."
    }
  ];

  const currentSteps = activeTab === "java" ? javaSteps : bedrockSteps;

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                How to <em className="font-medium text-[#4ade80]">Join</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-12 max-w-[65ch] mx-auto">
                Follow these simple steps to join Basic SMP and start your adventure today!
              </p>

              {/* Server IP Display */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => copyToClipboard(serverIPs.java)}
                  className="group flex items-center gap-3 px-8 py-4 bg-[#2d5a2d] border border-[#4ade80] rounded-2xl hover:bg-[#3d6a3d] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2"
                >
                  {copied ? (
                    <CheckCircle size={20} className="text-[#4ade80]" />
                  ) : (
                    <Copy size={20} className="text-[#4ade80]" />
                  )}
                  <div className="text-left">
                    <span className="text-white font-semibold text-[15px] block">
                      {copied ? "Copied!" : serverIPs.java}
                    </span>
                    <span className="text-[#a3d9a3] text-xs">
                      Java Edition Server IP
                    </span>
                  </div>
                </button>

                <button 
                  onClick={() => copyToClipboard(serverIPs.bedrock)}
                  className="group flex items-center gap-3 px-8 py-4 bg-[#2d5a2d] border border-[#4ade80] rounded-2xl hover:bg-[#3d6a3d] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2"
                >
                  {copied ? (
                    <CheckCircle size={20} className="text-[#4ade80]" />
                  ) : (
                    <Copy size={20} className="text-[#4ade80]" />
                  )}
                  <div className="text-left">
                    <span className="text-white font-semibold text-[15px] block">
                      {copied ? "Copied!" : serverIPs.bedrock}
                    </span>
                    <span className="text-[#a3d9a3] text-xs">
                      Bedrock Edition Server IP
                    </span>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Step-by-Step Guide */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[1000px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Step-by-Step <em className="text-[#4ade80]">Guide</em>
            </h2>

            {/* Platform Tabs */}
            <div className="flex justify-center mb-12">
              <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-2xl p-2">
                <button
                  onClick={() => setActiveTab("java")}
                  className={`flex items-center gap-3 px-6 py-3 rounded-2xl transition-colors duration-150 ${
                    activeTab === "java"
                      ? "bg-[#4ade80] text-[#0f1f0f]"
                      : "text-[#a3d9a3] hover:text-white"
                  }`}
                >
                  <Monitor size={20} />
                  Java Edition
                </button>
              </div>
              <div className="w-4"></div>
              <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-2xl p-2">
                <button
                  onClick={() => setActiveTab("bedrock")}
                  className={`flex items-center gap-3 px-6 py-3 rounded-2xl transition-colors duration-150 ${
                    activeTab === "bedrock"
                      ? "bg-[#4ade80] text-[#0f1f0f]"
                      : "text-[#a3d9a3] hover:text-white"
                  }`}
                >
                  <Smartphone size={20} />
                  Bedrock Edition
                </button>
              </div>
            </div>

            {/* Steps */}
            <div className="space-y-6">
              {currentSteps.map((step, index) => (
                <div
                  key={index}
                  className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8"
                >
                  <div className="flex items-start gap-6">
                    <div className="w-12 h-12 bg-[#4ade80] rounded-2xl flex items-center justify-center flex-shrink-0">
                      <span className="text-[#0f1f0f] font-bold text-lg">
                        {step.step}
                      </span>
                    </div>
                    
                    <div>
                      <h3 className="text-white font-semibold text-xl mb-3">
                        {step.title}
                      </h3>
                      
                      <div className="text-[#a3d9a3] leading-relaxed whitespace-pre-line">
                        {step.description}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 md:py-24 px-6 bg-[#0f1f0f]">
          <div className="max-w-[1000px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Frequently Asked <em className="text-[#4ade80]">Questions</em>
            </h2>

            <div className="space-y-4">
              {faqItems.map((faq, index) => (
                <div
                  key={index}
                  className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl overflow-hidden"
                >
                  <button
                    onClick={() => setExpandedFaq(expandedFaq === index ? null : index)}
                    className="w-full flex items-center justify-between p-6 text-left hover:bg-[#2d5a2d] transition-colors duration-150"
                  >
                    <div className="flex items-center gap-4">
                      <HelpCircle className="text-[#4ade80]" size={20} />
                      <span className="text-white font-semibold text-lg">
                        {faq.question}
                      </span>
                    </div>
                    
                    <div className={`text-[#4ade80] transition-transform duration-150 ${
                      expandedFaq === index ? 'rotate-180' : ''
                    }`}>
                      ▼
                    </div>
                  </button>
                  
                  {expandedFaq === index && (
                    <div className="px-6 pb-6">
                      <div className="text-[#a3d9a3] leading-relaxed border-t border-[#2d5a2d] pt-4">
                        {faq.answer}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Need Help Section */}
        <section className="py-16 px-6 bg-[#1a2f1a]">
          <div className="max-w-[800px] mx-auto text-center">
            <h2
              className="text-3xl md:text-[40px] leading-tight text-white mb-6"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Still need <em className="text-[#4ade80]">help</em>?
            </h2>
            
            <p className="text-[#a3d9a3] text-lg mb-8">
              Our friendly community is always ready to help new players get started!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="flex items-center justify-center gap-2 px-8 py-4 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#1a2f1a]">
                <ExternalLink size={20} />
                Join Discord Server
              </button>
              
              <button className="px-8 py-4 rounded-2xl border border-[#2d5a2d] text-[#4ade80] font-semibold text-lg hover:bg-[#0f1f0f] hover:border-[#4ade80] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#1a2f1a]">
                Contact Us
              </button>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}