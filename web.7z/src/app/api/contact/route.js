export async function POST(request) {
  try {
    const body = await request.json();
    const { name, email, subject, message } = body;

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return Response.json(
        { error: 'All fields are required' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return Response.json(
        { error: 'Invalid email format' },
        { status: 400 }
      );
    }

    // In a real application, you would:
    // 1. Store the contact form submission in a database
    // 2. Send an email notification to administrators
    // 3. Send a confirmation email to the user
    // 4. Potentially send to Discord webhook

    // For now, we'll just log the submission and return success
    console.log('Contact form submission:', {
      name,
      email,
      subject,
      message,
      timestamp: new Date().toISOString()
    });

    // Simulate sending to Discord webhook (you would replace this with actual webhook URL)
    const discordWebhookUrl = process.env.DISCORD_WEBHOOK_URL;
    if (discordWebhookUrl) {
      try {
        const discordMessage = {
          embeds: [{
            title: "New Contact Form Submission",
            color: 0x4ade80,
            fields: [
              { name: "Name", value: name, inline: true },
              { name: "Email", value: email, inline: true },
              { name: "Subject", value: subject },
              { name: "Message", value: message }
            ],
            timestamp: new Date().toISOString()
          }]
        };

        await fetch(discordWebhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(discordMessage),
        });
      } catch (error) {
        console.error('Error sending to Discord webhook:', error);
        // Don't fail the entire request if Discord webhook fails
      }
    }

    return Response.json(
      { 
        message: 'Contact form submitted successfully',
        success: true 
      },
      { status: 200 }
    );

  } catch (error) {
    console.error('Error processing contact form:', error);
    return Response.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}