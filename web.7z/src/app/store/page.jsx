import { useState } from "react";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { Crown, Coins, Tag, Key, ShoppingCart, Star, Zap } from "lucide-react";

export default function StorePage() {
  const [activeCategory, setActiveCategory] = useState("ranks");
  const [cart, setCart] = useState([]);

  const categories = [
    { id: "ranks", name: "Ranks", icon: Crown },
    { id: "currency", name: "Currency", icon: Coins },
    { id: "items", name: "Items", icon: Tag },
    { id: "cosmetics", name: "Cosmetics", icon: Zap },
  ];

  const products = {
    ranks: [
      {
        id: 1,
        name: "VIP Rank",
        price: 4.99,
        description: "Access to VIP perks, colored chat, and exclusive areas",
        features: ["Colored chat", "VIP tag", "Priority support", "Exclusive areas"],
        popular: false
      },
      {
        id: 2,
        name: "MVP Rank",
        price: 9.99,
        description: "Enhanced gameplay with special commands and privileges",
        features: ["All VIP features", "Extra homes", "Kit access", "Nickname colors"],
        popular: true
      },
      {
        id: 3,
        name: "Legend Rank",
        price: 19.99,
        description: "Ultimate server experience with maximum benefits",
        features: ["All MVP features", "Exclusive items", "Custom commands", "Priority queue"],
        popular: false
      }
    ],
    currency: [
      {
        id: 4,
        name: "1,000 Coins",
        price: 2.99,
        description: "Basic coin package for starter purchases",
        features: ["Instant delivery", "Safe transaction", "No expiration"],
        popular: false
      },
      {
        id: 5,
        name: "5,000 Coins",
        price: 9.99,
        description: "Popular choice for medium purchases and upgrades",
        features: ["Instant delivery", "Safe transaction", "No expiration", "15% bonus coins"],
        popular: true
      },
      {
        id: 6,
        name: "15,000 Coins",
        price: 24.99,
        description: "Large coin package for serious players",
        features: ["Instant delivery", "Safe transaction", "No expiration", "25% bonus coins"],
        popular: false
      }
    ],
    items: [
      {
        id: 7,
        name: "Crate Keys (5x)",
        price: 7.99,
        description: "Unlock treasure crates for rare items and rewards",
        features: ["Random rare items", "Exclusive cosmetics", "Special tools"],
        popular: true
      },
      {
        id: 8,
        name: "Land Claim Boost",
        price: 3.99,
        description: "Expand your protected territory with extra claim blocks",
        features: ["5000 claim blocks", "Instant activation", "Permanent upgrade"],
        popular: false
      }
    ],
    cosmetics: [
      {
        id: 9,
        name: "Custom Tags Pack",
        price: 4.99,
        description: "Express yourself with unique chat tags and titles",
        features: ["10 custom tags", "Color customization", "Priority display"],
        popular: false
      },
      {
        id: 10,
        name: "Particle Effects",
        price: 6.99,
        description: "Stand out with amazing particle trails and effects",
        features: ["5 particle effects", "Trail customization", "Special occasions"],
        popular: true
      }
    ]
  };

  const addToCart = (product) => {
    const existingItem = cart.find(item => item.id === product.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.id === product.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2);
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const currentProducts = products[activeCategory] || [];

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                Basic SMP <em className="font-medium text-[#4ade80]">Store</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-12 max-w-[65ch] mx-auto">
                Support the server and enhance your gameplay experience with our premium items and ranks.
              </p>

              {/* Cart Summary */}
              {cart.length > 0 && (
                <div className="bg-[#2d5a2d] border border-[#4ade80] rounded-2xl px-6 py-4 inline-block">
                  <div className="flex items-center gap-4">
                    <ShoppingCart className="text-[#4ade80]" size={20} />
                    <span className="text-white font-semibold">
                      {getTotalItems()} items in cart - ${getTotalPrice()}
                    </span>
                    <button className="bg-[#4ade80] text-[#0f1f0f] px-4 py-2 rounded-lg font-semibold hover:bg-[#22c55e] transition-colors">
                      Checkout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Store Content */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[1400px] mx-auto">
            <div className="flex flex-col lg:flex-row gap-8">
              
              {/* Sidebar Categories */}
              <div className="lg:w-1/4">
                <h2 className="text-white font-semibold text-xl mb-6">Categories</h2>
                <div className="space-y-2">
                  {categories.map((category) => {
                    const IconComponent = category.icon;
                    return (
                      <button
                        key={category.id}
                        onClick={() => setActiveCategory(category.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-colors duration-150 ${
                          activeCategory === category.id
                            ? "bg-[#4ade80] text-[#0f1f0f]"
                            : "bg-[#0f1f0f] text-white hover:bg-[#2d5a2d]"
                        }`}
                      >
                        <IconComponent size={20} />
                        {category.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Products Grid */}
              <div className="lg:w-3/4">
                <div className="flex items-center justify-between mb-8">
                  <h2
                    className="text-3xl md:text-[40px] leading-tight text-white"
                    style={{
                      fontFamily: "Instrument Serif, serif",
                      fontWeight: "500",
                    }}
                  >
                    {categories.find(c => c.id === activeCategory)?.name}
                  </h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                  {currentProducts.map((product) => (
                    <div
                      key={product.id}
                      className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-6 hover:border-[#4ade80] transition-colors duration-200 relative"
                    >
                      {product.popular && (
                        <div className="absolute -top-3 left-6">
                          <div className="bg-[#4ade80] text-[#0f1f0f] px-4 py-1 rounded-full text-sm font-semibold flex items-center gap-1">
                            <Star size={14} />
                            Popular
                          </div>
                        </div>
                      )}

                      <div className="mb-4">
                        <h3 className="text-white font-semibold text-xl mb-2">
                          {product.name}
                        </h3>
                        <p className="text-[#a3d9a3] text-sm mb-4">
                          {product.description}
                        </p>
                        
                        {/* Features */}
                        <ul className="space-y-1 mb-6">
                          {product.features.map((feature, index) => (
                            <li key={index} className="text-[#a3d9a3] text-sm flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-[#4ade80] rounded-full"></div>
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="text-2xl font-bold text-[#4ade80]">
                          ${product.price}
                        </div>
                        
                        <button
                          onClick={() => addToCart(product)}
                          className="bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold px-4 py-2 rounded-xl transition-colors duration-150 flex items-center gap-2"
                        >
                          <ShoppingCart size={16} />
                          Add to Cart
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Shopping Cart */}
        {cart.length > 0 && (
          <section className="py-16 px-6 bg-[#0f1f0f]">
            <div className="max-w-[1000px] mx-auto">
              <h2
                className="text-3xl md:text-[40px] leading-tight text-white mb-8 text-center"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  fontWeight: "500",
                }}
              >
                Shopping <em className="text-[#4ade80]">Cart</em>
              </h2>

              <div className="space-y-4 mb-8">
                {cart.map((item) => (
                  <div key={item.id} className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6 flex items-center justify-between">
                    <div>
                      <h3 className="text-white font-semibold text-lg">{item.name}</h3>
                      <p className="text-[#a3d9a3]">Quantity: {item.quantity}</p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <span className="text-[#4ade80] font-bold text-lg">
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-400 hover:text-red-300 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-8 text-center">
                <div className="text-white text-xl mb-4">
                  Total: <span className="text-[#4ade80] font-bold text-2xl">${getTotalPrice()}</span>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button className="px-8 py-4 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#0f1f0f]">
                    Proceed to Checkout
                  </button>
                  
                  <button 
                    onClick={() => setCart([])}
                    className="px-8 py-4 rounded-2xl border border-[#2d5a2d] text-[#a3d9a3] font-semibold text-lg hover:bg-[#2d5a2d] hover:text-white transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#0f1f0f]"
                  >
                    Clear Cart
                  </button>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Store Info */}
        <section className="py-16 px-6 bg-[#1a2f1a]">
          <div className="max-w-[800px] mx-auto text-center">
            <h2
              className="text-3xl md:text-[40px] leading-tight text-white mb-6"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Safe & Secure <em className="text-[#4ade80]">Payments</em>
            </h2>
            
            <p className="text-[#a3d9a3] text-lg mb-8">
              All purchases are processed securely and delivered instantly to your account.
              Support the server while enhancing your gameplay experience!
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-2xl p-6">
                <div className="text-[#4ade80] text-3xl mb-3">🔒</div>
                <h3 className="text-white font-semibold mb-2">Secure Payment</h3>
                <p className="text-[#a3d9a3] text-sm">SSL encrypted transactions</p>
              </div>
              
              <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-2xl p-6">
                <div className="text-[#4ade80] text-3xl mb-3">⚡</div>
                <h3 className="text-white font-semibold mb-2">Instant Delivery</h3>
                <p className="text-[#a3d9a3] text-sm">Items delivered immediately</p>
              </div>
              
              <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-2xl p-6">
                <div className="text-[#4ade80] text-3xl mb-3">💬</div>
                <h3 className="text-white font-semibold mb-2">24/7 Support</h3>
                <p className="text-[#a3d9a3] text-sm">Help when you need it</p>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}