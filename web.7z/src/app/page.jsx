import Header from "../components/Header";
import Hero from "../components/Hero";
import Features from "../components/Features";
import ServerInfo from "../components/ServerInfo";
import Screenshots from "../components/Screenshots";
import Footer from "../components/Footer";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#0a0f0a]">
      {/* HEADER SECTION */}
      <Header />

      {/* HERO SECTION */}
      <Hero />

      {/* FEATURES SECTION */}
      <Features />

      {/* SERVER INFO SECTION */}
      <ServerInfo />

      {/* SCREENSHOTS SECTION */}
      <Screenshots />

      {/* FOOTER SECTION */}
      <Footer />
    </div>
  );
}
