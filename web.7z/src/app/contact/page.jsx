import { useState } from "react";
import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { Mail, MessageSquare, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      setSubmitStatus('success');
      setFormData({ name: "", email: "", subject: "", message: "" });
    } catch (error) {
      console.error('Error submitting form:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactMethods = [
    {
      icon: MessageSquare,
      title: "Discord Server",
      description: "Join our community for real-time support and discussions",
      action: "Join Discord",
      link: "#"
    },
    {
      icon: Mail,
      title: "Email Support",
      description: "Send us an email and we'll get back to you within 24 hours",
      action: "Send Email",
      link: "mailto:support@basicsmp.com"
    }
  ];

  const faqItems = [
    {
      question: "How quickly do you respond to messages?",
      answer: "We typically respond to contact form submissions and emails within 24 hours. For urgent matters, Discord is your best bet for immediate assistance."
    },
    {
      question: "What should I include in my message?",
      answer: "Please include as much detail as possible about your issue or question. If it's technical, include your Minecraft username, the issue you're experiencing, and any error messages."
    },
    {
      question: "Can I suggest new features for the server?",
      answer: "Absolutely! We love hearing feedback and suggestions from our community. Use the contact form or post your ideas in our Discord suggestions channel."
    }
  ];

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                Contact <em className="font-medium text-[#4ade80]">Us</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-12 max-w-[65ch] mx-auto">
                Have a question, suggestion, or need help? We're here to assist you!
              </p>
            </div>
          </div>
        </section>

        {/* Contact Methods */}
        <section className="py-16 px-6 bg-[#1a2f1a]">
          <div className="max-w-[1000px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Get in <em className="text-[#4ade80]">Touch</em>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              {contactMethods.map((method, index) => {
                const IconComponent = method.icon;
                return (
                  <div
                    key={index}
                    className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8 hover:border-[#4ade80] transition-colors duration-200"
                  >
                    <div className="w-12 h-12 bg-[#2d5a2d] rounded-2xl flex items-center justify-center mb-4">
                      <IconComponent className="text-[#4ade80]" size={24} />
                    </div>
                    
                    <h3 className="text-white font-semibold text-xl mb-3">
                      {method.title}
                    </h3>
                    
                    <p className="text-[#a3d9a3] leading-relaxed mb-6">
                      {method.description}
                    </p>

                    <a
                      href={method.link}
                      className="inline-flex items-center gap-2 bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold px-6 py-3 rounded-xl transition-colors duration-150"
                    >
                      {method.action}
                      <ExternalLink size={16} />
                    </a>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Contact Form */}
        <section className="py-16 md:py-24 px-6 bg-[#0f1f0f]">
          <div className="max-w-[800px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Send us a <em className="text-[#4ade80]">Message</em>
            </h2>

            <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-3xl p-8 md:p-12">
              {/* Status Messages */}
              {submitStatus === 'success' && (
                <div className="mb-6 p-4 bg-green-900/20 border border-green-500 rounded-2xl flex items-center gap-3">
                  <CheckCircle className="text-green-400" size={20} />
                  <span className="text-green-400">Message sent successfully! We'll get back to you soon.</span>
                </div>
              )}

              {submitStatus === 'error' && (
                <div className="mb-6 p-4 bg-red-900/20 border border-red-500 rounded-2xl flex items-center gap-3">
                  <AlertCircle className="text-red-400" size={20} />
                  <span className="text-red-400">Failed to send message. Please try again or contact us via Discord.</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-[#0f1f0f] border border-[#2d5a2d] text-white placeholder-[#a3d9a3] focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:border-transparent"
                      placeholder="Your name"
                    />
                  </div>

                  <div>
                    <label className="block text-white font-semibold mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 rounded-xl bg-[#0f1f0f] border border-[#2d5a2d] text-white placeholder-[#a3d9a3] focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:border-transparent"
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">
                    Subject *
                  </label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded-xl bg-[#0f1f0f] border border-[#2d5a2d] text-white placeholder-[#a3d9a3] focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:border-transparent"
                    placeholder="What's this about?"
                  />
                </div>

                <div>
                  <label className="block text-white font-semibold mb-2">
                    Message *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 rounded-xl bg-[#0f1f0f] border border-[#2d5a2d] text-white placeholder-[#a3d9a3] focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:border-transparent resize-vertical"
                    placeholder="Tell us more about your question or issue..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full px-8 py-4 rounded-xl bg-[#4ade80] hover:bg-[#22c55e] disabled:bg-[#2d5a2d] disabled:text-[#a3d9a3] text-[#0f1f0f] font-semibold text-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#1a2f1a]"
                >
                  {isSubmitting ? "Sending..." : "Send Message"}
                </button>
              </form>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[1000px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Common <em className="text-[#4ade80]">Questions</em>
            </h2>

            <div className="space-y-6">
              {faqItems.map((faq, index) => (
                <div
                  key={index}
                  className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-2xl p-8"
                >
                  <h3 className="text-white font-semibold text-lg mb-3">
                    {faq.question}
                  </h3>
                  <p className="text-[#a3d9a3] leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}