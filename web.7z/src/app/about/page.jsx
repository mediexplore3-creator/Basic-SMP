import Header from "../../components/Header";
import Footer from "../../components/Footer";
import { Heart, Users, Trophy, Target } from "lucide-react";

export default function AboutPage() {
  const teamValues = [
    {
      icon: Heart,
      title: "Community First",
      description: "We believe in building a welcoming community where every player matters and friendships are formed."
    },
    {
      icon: Users,
      title: "Fair Play",
      description: "Our commitment to fairness ensures everyone has an equal opportunity to enjoy and succeed in our world."
    },
    {
      icon: Trophy,
      title: "Quality Experience",
      description: "We maintain high standards for server performance, plugins, and overall gameplay quality."
    },
    {
      icon: Target,
      title: "Continuous Growth",
      description: "We constantly evolve and improve based on community feedback to create the best possible experience."
    }
  ];

  const testimonials = [
    {
      name: "Alex M.",
      role: "Player since 2023",
      message: "Basic SMP has the best community I've ever been part of. The staff is amazing and the players are so welcoming!",
      avatar: "🎮"
    },
    {
      name: "Sarah K.",
      role: "Builder & PvP Enthusiast",
      message: "The perfect balance of survival and PvP. Love the land protection system and the weekly events are always fun!",
      avatar: "🏗️"
    },
    {
      name: "Mike D.",
      role: "Economy Expert",
      message: "The server economy is well-balanced and the trading system makes it easy to get resources and make friends.",
      avatar: "💎"
    }
  ];

  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                About <em className="font-medium text-[#4ade80]">Basic SMP</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-8 max-w-[65ch] mx-auto">
                Learn about our story, mission, and the community that makes Basic SMP special.
              </p>
            </div>
          </div>
        </section>

        {/* Our Story Section */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[1000px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-8 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Our <em className="text-[#4ade80]">Story</em>
            </h2>
            
            <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8 md:p-12">
              <div className="text-[#a3d9a3] text-lg leading-relaxed space-y-6">
                <p>
                  Basic SMP was born from a simple idea: create a Minecraft server where players can 
                  experience the best of survival gameplay while being part of a welcoming, inclusive community.
                </p>
                
                <p>
                  Founded in 2023, our server started small with just a handful of dedicated players who 
                  shared a vision of fair play, creativity, and mutual respect. What began as a modest 
                  survival world has grown into a thriving community of builders, explorers, and adventurers 
                  from around the globe.
                </p>
                
                <p>
                  Today, Basic SMP stands as a testament to what's possible when passionate gamers come 
                  together. We've maintained our core values of simplicity and fairness while expanding 
                  to offer cross-play support, engaging events, and innovative features that enhance 
                  the vanilla Minecraft experience.
                </p>
                
                <p>
                  Our commitment remains unchanged: to provide a stable, fun, and fair environment where 
                  every player can build their dreams, forge lasting friendships, and create memories 
                  that will last a lifetime.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Team Values Section */}
        <section className="py-16 md:py-24 px-6 bg-[#0f1f0f]">
          <div className="max-w-[1200px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Our <em className="text-[#4ade80]">Values</em>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {teamValues.map((value, index) => {
                const IconComponent = value.icon;
                return (
                  <div
                    key={index}
                    className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-3xl p-8 hover:border-[#4ade80] transition-colors duration-200"
                  >
                    <div className="w-12 h-12 bg-[#2d5a2d] rounded-2xl flex items-center justify-center mb-4">
                      <IconComponent className="text-[#4ade80]" size={24} />
                    </div>
                    
                    <h3 className="text-white font-semibold text-xl mb-3">
                      {value.title}
                    </h3>
                    
                    <p className="text-[#a3d9a3] leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Player Testimonials Section */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <h2
              className="text-3xl md:text-[48px] leading-tight text-white mb-12 text-center"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              What Players <em className="text-[#4ade80]">Say</em>
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8"
                >
                  <div className="text-center mb-6">
                    <div className="text-4xl mb-3">{testimonial.avatar}</div>
                    <h3 className="text-white font-semibold text-lg">
                      {testimonial.name}
                    </h3>
                    <p className="text-[#4ade80] text-sm">
                      {testimonial.role}
                    </p>
                  </div>
                  
                  <blockquote className="text-[#a3d9a3] text-center leading-relaxed">
                    "{testimonial.message}"
                  </blockquote>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 px-6 bg-[#0f1f0f]">
          <div className="max-w-[800px] mx-auto text-center">
            <h2
              className="text-3xl md:text-[40px] leading-tight text-white mb-6"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Ready to join our <em className="text-[#4ade80]">community</em>?
            </h2>
            
            <p className="text-[#a3d9a3] text-lg mb-8">
              Become part of something special. Start your Basic SMP journey today!
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="px-8 py-4 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#0f1f0f]">
                How to Join
              </button>
              
              <button className="px-8 py-4 rounded-2xl border border-[#2d5a2d] text-[#4ade80] font-semibold text-lg hover:bg-[#1a2f1a] hover:border-[#4ade80] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#0f1f0f]">
                Join Discord
              </button>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}