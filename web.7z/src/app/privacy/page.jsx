import Header from "../../components/Header";
import Footer from "../../components/Footer";

export default function PrivacyPage() {
  return (
    <>
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />
      
      <div className="min-h-screen bg-[#0a0f0a]">
        <Header />
        
        {/* Hero Section */}
        <section className="py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]">
          <div className="max-w-[1200px] mx-auto">
            <div className="text-center mb-16">
              <h1
                className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  letterSpacing: "-0.05em",
                }}
              >
                Privacy <em className="font-medium text-[#4ade80]">Policy</em>
              </h1>
              
              <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-8 max-w-[65ch] mx-auto">
                Learn how we collect, use, and protect your information on Basic SMP.
              </p>
              
              <p className="text-sm text-[#a3d9a3]">
                Last updated: January 15, 2025
              </p>
            </div>
          </div>
        </section>

        {/* Privacy Policy Content */}
        <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
          <div className="max-w-[800px] mx-auto">
            <div className="bg-[#0f1f0f] border border-[#2d5a2d] rounded-3xl p-8 md:p-12">
              <div className="prose prose-invert prose-green max-w-none">
                <div className="text-[#a3d9a3] leading-relaxed space-y-8">
                  
                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">1. Information We Collect</h2>
                    <p className="mb-4">
                      We collect information you provide directly to us, such as when you:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Join our Minecraft server using your Minecraft username</li>
                      <li>Fill out contact forms on our website</li>
                      <li>Make purchases in our online store</li>
                      <li>Join our Discord community</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">2. How We Use Your Information</h2>
                    <p className="mb-4">
                      We use the information we collect to:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Provide and maintain our Minecraft server services</li>
                      <li>Process your transactions and deliver purchased items</li>
                      <li>Send you technical notices and support messages</li>
                      <li>Respond to your comments and questions</li>
                      <li>Improve our services and website</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">3. Information Sharing</h2>
                    <p className="mb-4">
                      We do not sell, trade, or otherwise transfer your personal information to third parties except:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>With your consent</li>
                      <li>To process payments through secure payment processors</li>
                      <li>To comply with legal obligations</li>
                      <li>To protect our rights and safety</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">4. Data Security</h2>
                    <p>
                      We implement appropriate security measures to protect your personal information 
                      against unauthorized access, alteration, disclosure, or destruction. However, 
                      no method of transmission over the internet is 100% secure.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">5. Minecraft-Specific Information</h2>
                    <p className="mb-4">
                      When you join our Minecraft server, we may collect:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Your Minecraft username and UUID</li>
                      <li>IP address for security and administration purposes</li>
                      <li>In-game statistics and progress</li>
                      <li>Chat messages (for moderation purposes)</li>
                    </ul>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">6. Cookies and Tracking</h2>
                    <p>
                      Our website may use cookies and similar tracking technologies to improve 
                      your browsing experience and analyze website traffic. You can control 
                      cookie settings through your browser preferences.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">7. Children's Privacy</h2>
                    <p>
                      Our services are not directed to children under 13. If you are under 13, 
                      please do not provide any personal information. If we learn we have collected 
                      personal information from a child under 13, we will delete it promptly.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">8. Changes to This Policy</h2>
                    <p>
                      We may update this privacy policy from time to time. We will notify you of 
                      any changes by posting the new privacy policy on this page and updating 
                      the "last updated" date.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-semibold text-white mb-4">9. Contact Us</h2>
                    <p className="mb-4">
                      If you have any questions about this privacy policy, please contact us:
                    </p>
                    <ul className="list-disc pl-6 space-y-2">
                      <li>Through our website contact form</li>
                      <li>Via Discord: Join our server for immediate assistance</li>
                      <li>Email: support@basicsmp.com</li>
                    </ul>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </section>

        <Footer />
      </div>
    </>
  );
}