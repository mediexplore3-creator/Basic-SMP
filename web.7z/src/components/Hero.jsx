import { useState, useEffect } from "react";
import { Copy, CheckCircle, Users, Globe, Gamepad2 } from "lucide-react";

export default function Hero() {
  const [copied, setCopied] = useState(false);
  const [onlineCount, setOnlineCount] = useState(42);

  const serverIP = "play.basicsmp.com";

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(serverIP);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = serverIP;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Simulate online players updating
  useEffect(() => {
    const interval = setInterval(() => {
      setOnlineCount(prev => prev + (Math.random() > 0.5 ? 1 : -1));
    }, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* Google Fonts import */}
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital,wght@0,400;1,400&family=Inter:wght@400;600&display=swap"
        rel="stylesheet"
      />

      <section
        className="relative py-20 md:py-32 px-6 bg-gradient-to-b from-[#0f1f0f] to-[#1a2f1a]"
        style={{
          fontFamily: "Inter, system-ui, sans-serif",
        }}
      >
        <div className="max-w-[1200px] mx-auto">
          {/* Headline Block */}
          <div className="text-center mb-12">
            <h1
              className="text-4xl md:text-[64px] leading-tight md:leading-[1.1] text-white mb-6 max-w-4xl mx-auto"
              style={{
                fontFamily: "Instrument Serif, Playfair Display, serif",
                letterSpacing: "-0.05em",
              }}
            >
              Welcome to <em className="font-medium text-[#4ade80]">Basic SMP</em>
              <br />
              Your ultimate survival experience
            </h1>

            {/* Sub-headline */}
            <p className="text-base md:text-lg text-[#a3d9a3] opacity-80 mb-8 max-w-[55ch] mx-auto">
              Join our thriving community of survivors. Cross-play enabled for Java & Bedrock players.
            </p>

            {/* Server IP Copy Section */}
            <div className="flex flex-col sm:flex-row justify-center items-center gap-3 sm:gap-4 mb-12">
              {/* Copy IP button */}
              <button 
                onClick={copyToClipboard}
                className="group flex items-center gap-3 px-8 py-4 bg-[#2d5a2d] border border-[#4ade80] rounded-2xl hover:bg-[#3d6a3d] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2"
              >
                {copied ? (
                  <CheckCircle size={20} className="text-[#4ade80]" />
                ) : (
                  <Copy size={20} className="text-[#4ade80]" />
                )}
                <div className="text-left">
                  <span className="text-white font-semibold text-[15px] block">
                    {copied ? "Copied!" : serverIP}
                  </span>
                  <span className="text-[#a3d9a3] text-xs">
                    {copied ? "Server IP copied to clipboard" : "Click to copy server IP"}
                  </span>
                </div>
              </button>

              {/* Join Discord button */}
              <button
                className="px-8 py-4 rounded-2xl text-[#0f1f0f] font-semibold text-[15px] transition-all duration-150 hover:bg-[#22c55e] focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 bg-[#4ade80]"
              >
                Join Discord
              </button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
              <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                <Users className="text-[#4ade80] mb-2 mx-auto" size={24} />
                <div className="text-white font-semibold text-xl">{onlineCount}</div>
                <div className="text-[#a3d9a3] text-sm">Players Online</div>
              </div>
              
              <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                <Globe className="text-[#4ade80] mb-2 mx-auto" size={24} />
                <div className="text-white font-semibold text-xl">24/7</div>
                <div className="text-[#a3d9a3] text-sm">Uptime</div>
              </div>
              
              <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                <Gamepad2 className="text-[#4ade80] mb-2 mx-auto" size={24} />
                <div className="text-white font-semibold text-xl">1.20+</div>
                <div className="text-[#a3d9a3] text-sm">Version Support</div>
              </div>
            </div>
          </div>

          {/* Featured Server Image */}
          <div className="relative max-w-[1000px] mx-auto mt-16">
            <div className="relative">
              {/* Main server showcase image */}
              <div
                className="relative rounded-3xl border-2 border-[#2d5a2d] overflow-hidden bg-[#1a2f1a]"
                style={{
                  boxShadow: "0 18px 30px rgba(0,0,0,0.3)",
                  height: "400px",
                }}
              >
                <div 
                  className="w-full h-full bg-gradient-to-br from-[#2d5a2d] to-[#1a2f1a] flex items-center justify-center"
                  style={{
                    backgroundImage: "url('data:image/svg+xml,%3Csvg width=\"60\" height=\"60\" viewBox=\"0 0 60 60\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cg fill=\"none\" fill-rule=\"evenodd\"%3E%3Cg fill=\"%234ade80\" fill-opacity=\"0.1\"%3E%3Cpath d=\"m36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')",
                  }}
                >
                  <div className="text-center">
                    <div className="text-6xl mb-4">🏰</div>
                    <h3 className="text-2xl font-semibold text-white mb-2">
                      Basic SMP World
                    </h3>
                    <p className="text-[#a3d9a3]">
                      Explore our custom-built survival world
                    </p>
                  </div>
                </div>
              </div>

              {/* Live status indicator */}
              <div className="absolute top-4 left-4">
                <div className="flex items-center gap-2 bg-[#0f1f0f] bg-opacity-90 backdrop-blur-sm border border-[#4ade80] rounded-full px-4 py-2">
                  <div className="w-2 h-2 bg-[#4ade80] rounded-full animate-pulse"></div>
                  <span className="text-[#4ade80] text-sm font-medium">LIVE</span>
                </div>
              </div>

              {/* Version badges */}
              <div className="absolute bottom-4 right-4 flex gap-2">
                <div className="bg-[#4ade80] text-[#0f1f0f] px-3 py-1 rounded-full text-sm font-semibold">
                  Java
                </div>
                <div className="bg-[#4ade80] text-[#0f1f0f] px-3 py-1 rounded-full text-sm font-semibold">
                  Bedrock
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}