import { useState } from "react";
import { Sword, Coins, Calendar, Shield, Zap, Trophy } from "lucide-react";

export default function Features() {
  const [hoveredCard, setHoveredCard] = useState(null);

  const features = [
    {
      id: "survival",
      icon: Shield,
      title: "Survival Mode",
      description: "Experience pure vanilla survival with custom enhancements and community-driven gameplay.",
      isActive: true,
    },
    {
      id: "pvp",
      icon: Sword,
      title: "PvP Battles",
      description: "Engage in thrilling player vs player combat in designated areas with fair play rules.",
    },
    {
      id: "economy",
      icon: Coins,
      title: "Server Economy",
      description: "Trade, buy, and sell with other players using our balanced in-game economy system.",
    },
    {
      id: "events",
      icon: Calendar,
      title: "Weekly Events",
      description: "Participate in exciting community events, competitions, and server-wide challenges.",
    },
    {
      id: "land-claim",
      icon: Zap,
      title: "Land Protection",
      description: "Protect your builds and items with our advanced land claiming and grief prevention system.",
    },
    {
      id: "bedwars",
      icon: Trophy,
      title: "BedWars Arena",
      description: "Jump into fast-paced BedWars matches with friends and compete for the top spot on leaderboards.",
    },
  ];

  const isCardActive = (feature) => {
    return feature.isActive || hoveredCard === feature.id;
  };

  return (
    <>
      {/* Google Fonts import */}
      <link
        href="https://fonts.googleapis.com/css2?family=Libre+Caslon+Text:ital,wght@0,400;0,700;1,400;1,700&family=Inter:wght@400;600&display=swap"
        rel="stylesheet"
      />

      <section className="py-16 md:py-24 px-6 bg-[#1a2f1a]">
        <div className="max-w-[1200px] mx-auto">
          {/* Section heading */}
          <div className="text-center mb-12 md:mb-16">
            <h2
              className="text-4xl md:text-[56px] leading-tight md:leading-[1.1] text-white mb-6 md:mb-8"
              style={{
                fontFamily: "Libre Caslon Text, serif",
                fontWeight: "700",
              }}
            >
              Why choose <em className="font-bold text-[#4ade80]">Basic SMP</em>?
            </h2>

            {/* Sub-headline */}
            <p
              className="text-base md:text-lg text-[#a3d9a3]"
              style={{
                fontFamily: "Inter, system-ui, sans-serif",
              }}
            >
              Experience the perfect blend of survival gameplay and community features
            </p>
          </div>

          {/* Feature cards grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-7">
            {features.map((feature) => {
              const IconComponent = feature.icon;
              const active = isCardActive(feature);

              return (
                <div
                  key={feature.id}
                  role="button"
                  tabIndex={0}
                  className={`
                    relative p-6 md:p-8 rounded-3xl border transition-all duration-200 ease-out cursor-pointer
                    focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-opacity-50
                    ${
                      active
                        ? "bg-[#4ade80] border-transparent text-[#0f1f0f]"
                        : "bg-[#0f1f0f] border-[#2d5a2d] hover:bg-[#1f2f1f] text-white"
                    }
                  `}
                  onMouseEnter={() => setHoveredCard(feature.id)}
                  onMouseLeave={() => setHoveredCard(null)}
                >
                  {/* Icon container */}
                  <div
                    className={`
                      w-12 h-12 rounded-2xl border flex items-center justify-center mb-4 transition-all duration-200 ease-out
                      ${
                        active
                          ? "bg-[#0f1f0f] border-[#0f1f0f]"
                          : "bg-[#1a2f1a] border-[#2d5a2d]"
                      }
                    `}
                  >
                    <IconComponent
                      size={24}
                      strokeWidth={1.5}
                      className={`transition-all duration-200 ease-out ${
                        active
                          ? "text-[#4ade80]"
                          : "text-[#4ade80]"
                      }`}
                    />
                  </div>

                  {/* Title */}
                  <h3
                    className={`
                      text-xl mb-3 transition-all duration-200 ease-out
                      ${active ? "text-[#0f1f0f]" : "text-white"}
                    `}
                    style={{
                      fontFamily: "Inter, system-ui, sans-serif",
                      fontWeight: "600",
                    }}
                  >
                    {feature.title}
                  </h3>

                  {/* Description */}
                  <p
                    className={`
                      text-base leading-relaxed transition-all duration-200 ease-out
                      ${active ? "text-[#0f1f0f] opacity-80" : "text-[#a3d9a3]"}
                    `}
                    style={{
                      fontFamily: "Inter, system-ui, sans-serif",
                      fontWeight: "400",
                      maxWidth: "55ch",
                    }}
                  >
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Call to action */}
          <div className="text-center mt-16">
            <button className="px-8 py-4 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#1a2f1a]">
              Start Your Adventure
            </button>
          </div>
        </div>
      </section>
    </>
  );
}