export default function Footer() {
  const navigationLinks = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "How to Join", href: "/join" },
    { name: "Store", href: "/store" },
    { name: "Contact", href: "/contact" },
    { name: "Discord", href: "#" },
  ];

  const legalLinks = [
    { name: "Privacy Policy", href: "/privacy" },
    { name: "Terms & Conditions", href: "/terms" },
    { name: "DMCA Policy", href: "/dmca" },
  ];

  const socialLinks = [
    { name: "Discord", href: "#", icon: "🎮" },
    { name: "YouTube", href: "#", icon: "📺" },
    { name: "Instagram", href: "#", icon: "📸" },
  ];

  return (
    <>
      {/* Google Fonts import */}
      <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap"
        rel="stylesheet"
      />

      <footer
        className="bg-[#0f1f0f] border-t border-[#2d5a2d] py-16 px-6"
        style={{ fontFamily: "Inter, system-ui, sans-serif" }}
      >
        <div className="max-w-[1280px] mx-auto">
          {/* Logo and Brand - Centered */}
          <div className="text-center mb-16">
            <div className="flex items-center justify-center space-x-3 mb-8">
              <div className="w-10 h-10 bg-[#4ade80] rounded-lg flex items-center justify-center">
                <span className="text-[#0f1f0f] font-bold text-lg">B</span>
              </div>
              <span
                className="text-white text-[24px] font-semibold"
                style={{ fontFamily: "Inter, system-ui, sans-serif" }}
              >
                Basic SMP
              </span>
            </div>

            <p className="text-[#a3d9a3] text-lg max-w-2xl mx-auto mb-8">
              Join our thriving Minecraft community where survival meets adventure. 
              Cross-play enabled for Java & Bedrock players.
            </p>

            {/* Server IP Display */}
            <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl px-6 py-4 inline-block mb-8">
              <div className="text-[#4ade80] font-semibold text-sm mb-1">SERVER IP</div>
              <div className="text-white font-mono text-xl">play.basicsmp.com</div>
            </div>

            {/* Navigation Links */}
            <nav>
              <div className="flex flex-wrap items-center justify-center gap-8 md:gap-10">
                {navigationLinks.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    className="text-white opacity-80 hover:opacity-100 hover:text-[#4ade80] text-[16px] font-medium transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-inset rounded-sm px-2 py-1"
                    style={{ fontFamily: "Inter, system-ui, sans-serif" }}
                  >
                    {link.name}
                  </a>
                ))}
              </div>
            </nav>
          </div>

          {/* Social Media & Community */}
          <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0 mb-12">
            {/* Social Links */}
            <div>
              <h3 className="text-white font-semibold text-lg mb-4 text-center md:text-left">
                Join Our Community
              </h3>
              <div className="flex items-center justify-center md:justify-start space-x-4">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    className="flex items-center gap-2 bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl px-4 py-2 hover:bg-[#2d5a2d] hover:border-[#4ade80] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80]"
                  >
                    <span className="text-lg">{social.icon}</span>
                    <span className="text-white font-medium text-sm">
                      {social.name}
                    </span>
                  </a>
                ))}
              </div>
            </div>

            {/* Server Status */}
            <div className="text-center md:text-right">
              <div className="flex items-center gap-2 justify-center md:justify-end mb-2">
                <div className="w-2 h-2 bg-[#4ade80] rounded-full animate-pulse"></div>
                <span className="text-[#4ade80] font-semibold text-sm">SERVER ONLINE</span>
              </div>
              <div className="text-[#a3d9a3] text-sm">
                24/7 Uptime • Version 1.20+
              </div>
            </div>
          </div>

          {/* Bottom row - Copyright and Legal Links */}
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0 pt-8 border-t border-[#2d5a2d]">
            {/* Copyright */}
            <div
              className="text-[#a3d9a3] text-[14px] font-normal order-2 md:order-1"
              style={{ fontFamily: "Inter, system-ui, sans-serif" }}
            >
              © 2025 Basic SMP | Developed by Nitin Sharma
            </div>

            {/* Legal Links */}
            <div className="flex items-center order-1 md:order-2">
              {legalLinks.map((link, index) => (
                <div key={link.name} className="flex items-center">
                  <a
                    href={link.href}
                    className="text-[#a3d9a3] hover:text-[#4ade80] text-[14px] font-medium transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-inset rounded-sm px-2 py-1"
                    style={{ fontFamily: "Inter, system-ui, sans-serif" }}
                  >
                    {link.name}
                  </a>
                  {index < legalLinks.length - 1 && (
                    <span className="text-[#a3d9a3] text-[14px] mx-6">
                      |
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}