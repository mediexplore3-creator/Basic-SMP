import { useState, useEffect } from "react";
import { Server, MapPin, Clock, Users } from "lucide-react";

export default function ServerInfo() {
  const [serverStats, setServerStats] = useState({
    uptime: "99.9%",
    location: "North America",
    maxPlayers: 100,
    version: "1.20.1",
    plugins: 25,
  });

  const [newsItems, setNewsItems] = useState([
    {
      id: 1,
      title: "Winter Event Now Live!",
      description: "Join our special winter-themed event with exclusive rewards and challenges.",
      date: "2025-01-15",
      type: "event"
    },
    {
      id: 2,
      title: "New Land Claim System",
      description: "Enhanced protection system now available for all players. Claim your territory today!",
      date: "2025-01-10", 
      type: "update"
    },
    {
      id: 3,
      title: "Economy Rebalance",
      description: "We've updated shop prices and trade values for a better gaming experience.",
      date: "2025-01-05",
      type: "update"
    }
  ]);

  return (
    <>
      {/* Google Fonts import */}
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />

      <section className="py-16 md:py-24 px-6 bg-[#0f1f0f]">
        <div className="max-w-[1200px] mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 md:gap-16">
            
            {/* Server Statistics */}
            <div>
              <h2
                className="text-3xl md:text-[48px] leading-tight text-white mb-8"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  fontWeight: "500",
                }}
              >
                Server <em className="text-[#4ade80]">Statistics</em>
              </h2>

              <div className="space-y-6">
                {/* Uptime */}
                <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#2d5a2d] rounded-2xl flex items-center justify-center">
                      <Clock className="text-[#4ade80]" size={24} />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-lg">Server Uptime</h3>
                      <p className="text-[#4ade80] text-2xl font-bold">{serverStats.uptime}</p>
                      <p className="text-[#a3d9a3] text-sm">Rock solid reliability</p>
                    </div>
                  </div>
                </div>

                {/* Location */}
                <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#2d5a2d] rounded-2xl flex items-center justify-center">
                      <MapPin className="text-[#4ade80]" size={24} />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-lg">Server Location</h3>
                      <p className="text-[#4ade80] text-2xl font-bold">{serverStats.location}</p>
                      <p className="text-[#a3d9a3] text-sm">Low latency gaming</p>
                    </div>
                  </div>
                </div>

                {/* Capacity */}
                <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#2d5a2d] rounded-2xl flex items-center justify-center">
                      <Users className="text-[#4ade80]" size={24} />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-lg">Max Players</h3>
                      <p className="text-[#4ade80] text-2xl font-bold">{serverStats.maxPlayers}</p>
                      <p className="text-[#a3d9a3] text-sm">Room for everyone</p>
                    </div>
                  </div>
                </div>

                {/* Version */}
                <div className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#2d5a2d] rounded-2xl flex items-center justify-center">
                      <Server className="text-[#4ade80]" size={24} />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-lg">Minecraft Version</h3>
                      <p className="text-[#4ade80] text-2xl font-bold">{serverStats.version}</p>
                      <p className="text-[#a3d9a3] text-sm">Latest features</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Server News & Updates */}
            <div>
              <h2
                className="text-3xl md:text-[48px] leading-tight text-white mb-8"
                style={{
                  fontFamily: "Instrument Serif, serif",
                  fontWeight: "500",
                }}
              >
                Latest <em className="text-[#4ade80]">News</em>
              </h2>

              <div className="space-y-6">
                {newsItems.map((item) => (
                  <div key={item.id} className="bg-[#1a2f1a] border border-[#2d5a2d] rounded-2xl p-6 hover:border-[#4ade80] transition-colors duration-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        item.type === 'event' 
                          ? 'bg-[#4ade80] text-[#0f1f0f]' 
                          : 'bg-[#2d5a2d] text-[#4ade80]'
                      }`}>
                        {item.type.toUpperCase()}
                      </div>
                      <span className="text-[#a3d9a3] text-sm">
                        {new Date(item.date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric' 
                        })}
                      </span>
                    </div>
                    
                    <h3 className="text-white font-semibold text-lg mb-2">
                      {item.title}
                    </h3>
                    
                    <p className="text-[#a3d9a3] leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>

              {/* View all news button */}
              <div className="mt-8">
                <button className="w-full px-6 py-3 rounded-2xl border border-[#2d5a2d] text-[#4ade80] font-semibold hover:bg-[#1a2f1a] hover:border-[#4ade80] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#0f1f0f]">
                  View All Updates
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}