import { useState } from "react";
import { ChevronLeft, ChevronRight, Eye } from "lucide-react";

export default function Screenshots() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [hoveredImage, setHoveredImage] = useState(null);

  const screenshots = [
    {
      id: 1,
      title: "Spawn Town",
      description: "Welcome to our beautifully crafted spawn town where your adventure begins",
      image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=1200&q=80",
      category: "spawn"
    },
    {
      id: 2,
      title: "Player Builds",
      description: "Amazing structures built by our talented community members",
      image: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=1200&q=80",
      category: "builds"
    },
    {
      id: 3,
      title: "BedWars Arena",
      description: "Fast-paced PvP action in our custom BedWars arenas",
      image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80",
      category: "pvp"
    },
    {
      id: 4,
      title: "Market District",
      description: "Trade and shop with other players in our bustling marketplace",
      image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=1200&q=80",
      category: "economy"
    },
    {
      id: 5,
      title: "Adventure Lands",
      description: "Explore vast landscapes and discover hidden treasures",
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=1200&q=80",
      category: "exploration"
    },
    {
      id: 6,
      title: "Community Events",
      description: "Join weekly events and competitions with amazing prizes",
      image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80",
      category: "events"
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % Math.ceil(screenshots.length / 3));
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + Math.ceil(screenshots.length / 3)) % Math.ceil(screenshots.length / 3));
  };

  const getVisibleImages = () => {
    const startIndex = currentSlide * 3;
    return screenshots.slice(startIndex, startIndex + 3);
  };

  return (
    <>
      {/* Google Fonts import */}
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Serif:wght@400;500&family=Inter:wght@400;600;700&display=swap"
        rel="stylesheet"
      />

      <section className="py-16 md:py-24 px-6 bg-gradient-to-b from-[#1a2f1a] to-[#0f1f0f]">
        <div className="max-w-[1200px] mx-auto">
          {/* Section heading */}
          <div className="text-center mb-12 md:mb-16">
            <h2
              className="text-4xl md:text-[56px] leading-tight md:leading-[1.1] text-white mb-6 md:mb-8"
              style={{
                fontFamily: "Instrument Serif, serif",
                fontWeight: "500",
              }}
            >
              Server <em className="font-medium text-[#4ade80]">Showcase</em>
            </h2>

            {/* Sub-headline */}
            <p
              className="text-base md:text-lg text-[#a3d9a3]"
              style={{
                fontFamily: "Inter, system-ui, sans-serif",
              }}
            >
              Take a look at our amazing world and community creations
            </p>
          </div>

          {/* Screenshot Carousel */}
          <div className="relative">
            {/* Main carousel container */}
            <div className="overflow-hidden rounded-3xl">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {getVisibleImages().map((screenshot) => (
                  <div
                    key={screenshot.id}
                    className="relative group cursor-pointer"
                    onMouseEnter={() => setHoveredImage(screenshot.id)}
                    onMouseLeave={() => setHoveredImage(null)}
                  >
                    <div className="aspect-square overflow-hidden rounded-2xl bg-[#2d5a2d]">
                      <img
                        src={screenshot.image}
                        alt={screenshot.title}
                        className={`w-full h-full object-cover transition-transform duration-300 ${
                          hoveredImage === screenshot.id ? 'scale-110' : 'scale-100'
                        }`}
                      />
                      
                      {/* Overlay */}
                      <div className={`absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center transition-opacity duration-300 ${
                        hoveredImage === screenshot.id ? 'opacity-100' : 'opacity-0'
                      }`}>
                        <div className="text-center">
                          <Eye className="text-[#4ade80] mb-2 mx-auto" size={32} />
                          <h3 className="text-white font-semibold text-lg mb-1">
                            {screenshot.title}
                          </h3>
                          <p className="text-[#a3d9a3] text-sm px-4">
                            {screenshot.description}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Category badge */}
                    <div className="absolute top-4 left-4">
                      <span className="bg-[#4ade80] text-[#0f1f0f] px-3 py-1 rounded-full text-xs font-semibold uppercase">
                        {screenshot.category}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Navigation buttons */}
            {screenshots.length > 3 && (
              <>
                <button
                  onClick={prevSlide}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-[#1a2f1a] border border-[#2d5a2d] rounded-full flex items-center justify-center hover:bg-[#2d5a2d] hover:border-[#4ade80] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80]"
                >
                  <ChevronLeft className="text-[#4ade80]" size={20} />
                </button>
                
                <button
                  onClick={nextSlide}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-[#1a2f1a] border border-[#2d5a2d] rounded-full flex items-center justify-center hover:bg-[#2d5a2d] hover:border-[#4ade80] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80]"
                >
                  <ChevronRight className="text-[#4ade80]" size={20} />
                </button>
              </>
            )}

            {/* Slide indicators */}
            {screenshots.length > 3 && (
              <div className="flex justify-center mt-8 space-x-2">
                {Array.from({ length: Math.ceil(screenshots.length / 3) }).map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-colors duration-150 ${
                      index === currentSlide ? 'bg-[#4ade80]' : 'bg-[#2d5a2d]'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Call to action */}
          <div className="text-center mt-12">
            <p className="text-[#a3d9a3] mb-6">
              Ready to create your own legendary builds?
            </p>
            <button className="px-8 py-4 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-lg transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 focus:ring-offset-[#0f1f0f]">
              Join Basic SMP Today
            </button>
          </div>
        </div>
      </section>
    </>
  );
}