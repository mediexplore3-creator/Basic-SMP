import { useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const menuItems = [
    { name: "Home", href: "/" },
    { name: "About", href: "/about" },
    { name: "How to Join", href: "/join" },
    { name: "Store", href: "/store" },
    { name: "Contact", href: "/contact" },
  ];

  return (
    <>
      {/* Google Fonts import */}
      <link
        href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600&display=swap"
        rel="stylesheet"
      />

      <header
        className="bg-[#0f1f0f] dark:bg-[#0f1f0f] border-b border-[#2d5a2d] h-16 md:h-16 px-6"
        style={{ fontFamily: "Instrument Sans, Inter, system-ui, sans-serif" }}
      >
        <div className="max-w-[1200px] mx-auto flex items-center justify-between h-full">
          {/* Logo block */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[#4ade80] rounded-lg flex items-center justify-center">
              <span className="text-[#0f1f0f] font-bold text-sm">B</span>
            </div>
            <span className="text-white font-medium text-lg">
              Basic SMP
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {menuItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className="group flex items-center space-x-1 text-white opacity-90 hover:opacity-100 hover:text-[#4ade80] transition-colors duration-150 font-medium text-base focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 rounded-2xl px-2 py-1"
              >
                <span>{item.name}</span>
              </a>
            ))}
          </nav>

          {/* Desktop Action Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="px-6 py-3 rounded-2xl border border-[#2d5a2d] text-white font-semibold text-sm hover:bg-[#1f2f1f] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2">
              Discord
            </button>
            <button className="px-6 py-3 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-sm transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2">
              Play Now
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-white focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 rounded-2xl"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu Panel */}
        {isMobileMenuOpen && (
          <div className="md:hidden fixed inset-0 bg-[#0f1f0f] z-50 flex flex-col">
            {/* Mobile Header */}
            <div className="flex items-center justify-between h-14 px-6 border-b border-[#2d5a2d]">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#4ade80] rounded-lg flex items-center justify-center">
                  <span className="text-[#0f1f0f] font-bold text-sm">B</span>
                </div>
                <span className="text-white font-medium text-lg">
                  Basic SMP
                </span>
              </div>
              <button
                className="p-2 text-white focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2 rounded-2xl"
                onClick={() => setIsMobileMenuOpen(false)}
                aria-label="Close mobile menu"
              >
                <X size={24} />
              </button>
            </div>

            {/* Mobile Navigation */}
            <nav className="flex-1 px-6 py-6 space-y-4">
              {menuItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="flex items-center justify-between py-3 text-white opacity-90 hover:opacity-100 hover:text-[#4ade80] transition-colors duration-150 font-medium text-base border-b border-[#2d5a2d] last:border-b-0"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <span>{item.name}</span>
                </a>
              ))}
            </nav>

            {/* Mobile Action Buttons */}
            <div className="px-6 py-6 space-y-3 border-t border-[#2d5a2d]">
              <button
                className="w-full px-6 py-3 rounded-2xl border border-[#2d5a2d] text-white font-semibold text-sm hover:bg-[#1f2f1f] transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Discord
              </button>
              <button
                className="w-full px-6 py-3 rounded-2xl bg-[#4ade80] hover:bg-[#22c55e] text-[#0f1f0f] font-semibold text-sm transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-[#4ade80] focus:ring-offset-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Play Now
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
}